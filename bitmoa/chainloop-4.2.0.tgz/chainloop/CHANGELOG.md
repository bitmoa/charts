# Changelog

## 4.2.0 (2026-09-15)

* Bump `chainloop-control-plane` image to `1.109.4-debian-12-r0` (was `1.109.3-debian-12-r0`)

## 4.1.1 (2026-09-15)

* Bump `chainloop-artifact-cas` image to `1.109.4-debian-12-r0` (was `1.43.1-debian-12-r0`)

## 4.1.0 (2026-09-15)

* Bump `chainloop-control-plane` image to `1.109.3-debian-12-r0` (was `1.43.1-debian-12-r0`)

## 4.0.76 (2026-09-15)

* Bump `dex` image to `2.45.1-debian-12-r18` (was `2.43.1-debian-12-r0`)

## 4.0.75 (2025-08-27)

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references ([#36212](https://github.com/bitnami/charts/pull/36212))

## <small>4.0.74 (2025-08-22)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#36168) ([bbe18b6](https://github.com/bitnami/charts/commit/bbe18b6d1f102652d6c1574e58a5aaa7d93b15c2)), closes [#36168](https://github.com/bitnami/charts/issues/36168)

## <small>4.0.73 (2025-08-20)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#36152) ([f8b69f5](https://github.com/bitnami/charts/commit/f8b69f5b6ca872ece9a49717a3c8f1c03b92f231)), closes [#36152](https://github.com/bitnami/charts/issues/36152)

## <small>4.0.72 (2025-08-17)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#36093) ([dea72c9](https://github.com/bitnami/charts/commit/dea72c9d1d1291cde1982fcd156c3658bad5b6ea)), closes [#36093](https://github.com/bitnami/charts/issues/36093)

## <small>4.0.71 (2025-08-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35796) ([cca667e](https://github.com/bitnami/charts/commit/cca667e638b91713932041bfaadab90f58bb1412)), closes [#35796](https://github.com/bitnami/charts/issues/35796)

## <small>4.0.70 (2025-08-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35789) ([9c5910a](https://github.com/bitnami/charts/commit/9c5910ac12383a0b1dbf4d5a4505a36faa449db2)), closes [#35789](https://github.com/bitnami/charts/issues/35789)

## <small>4.0.69 (2025-08-12)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35761) ([4213451](https://github.com/bitnami/charts/commit/421345109bf7e9fd355ca47501dd99b3f1036223)), closes [#35761](https://github.com/bitnami/charts/issues/35761)

## <small>4.0.68 (2025-08-11)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35747) ([2b262a4](https://github.com/bitnami/charts/commit/2b262a493b7803c261017991707ed7cafcab110b)), closes [#35747](https://github.com/bitnami/charts/issues/35747)

## <small>4.0.67 (2025-08-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35707) ([2ba5b7d](https://github.com/bitnami/charts/commit/2ba5b7d5d0d4e7adbaf2fad3551d6dce9f368945)), closes [#35707](https://github.com/bitnami/charts/issues/35707)

## <small>4.0.66 (2025-08-07)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35545) ([f080548](https://github.com/bitnami/charts/commit/f080548361be923532a9ff4bc1fe0ab2ba6d9148)), closes [#35545](https://github.com/bitnami/charts/issues/35545)

## <small>4.0.65 (2025-08-07)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35465) ([1c0a1b2](https://github.com/bitnami/charts/commit/1c0a1b2c8a37395ab26a67979ff8b5391d40a3cb)), closes [#35465](https://github.com/bitnami/charts/issues/35465)

## <small>4.0.64 (2025-08-06)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35457) ([abf9726](https://github.com/bitnami/charts/commit/abf9726ba79d3d8e55a557ea63d65710a0e7fca6)), closes [#35457](https://github.com/bitnami/charts/issues/35457)

## <small>4.0.63 (2025-08-06)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35441) ([e2270d3](https://github.com/bitnami/charts/commit/e2270d3d7c71a19f25aafa9770b9f3a15b0c5e98)), closes [#35441](https://github.com/bitnami/charts/issues/35441)

## <small>4.0.62 (2025-08-05)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35422) ([22c553f](https://github.com/bitnami/charts/commit/22c553f35e8a3eafd48e9e1141be939c7ad6e50a)), closes [#35422](https://github.com/bitnami/charts/issues/35422)

## <small>4.0.61 (2025-08-05)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35413) ([67dbad7](https://github.com/bitnami/charts/commit/67dbad78f412690322471a9b104332cfc637cd30)), closes [#35413](https://github.com/bitnami/charts/issues/35413)

## <small>4.0.60 (2025-08-01)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35380) ([28652b6](https://github.com/bitnami/charts/commit/28652b6b91855cf96f26000ef47d5380e991b87e)), closes [#35380](https://github.com/bitnami/charts/issues/35380)

## <small>4.0.59 (2025-07-29)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35329) ([abc33b8](https://github.com/bitnami/charts/commit/abc33b864a32f67673ad013c0341297ee4cf4496)), closes [#35329](https://github.com/bitnami/charts/issues/35329)

## <small>4.0.58 (2025-07-28)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35319) ([01613a5](https://github.com/bitnami/charts/commit/01613a56783f1d3cb9b0ec3778774ba33332ab80)), closes [#35319](https://github.com/bitnami/charts/issues/35319)

## <small>4.0.57 (2025-07-25)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35296) ([8c1d1b6](https://github.com/bitnami/charts/commit/8c1d1b6315586c900ff5fbee7804f5bcbb02543f)), closes [#35296](https://github.com/bitnami/charts/issues/35296)

## <small>4.0.56 (2025-07-24)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35285) ([1d2fb18](https://github.com/bitnami/charts/commit/1d2fb181b9c7f93318f76bd43611c2122cbd22a8)), closes [#35285](https://github.com/bitnami/charts/issues/35285)

## <small>4.0.55 (2025-07-21)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35229) ([b46ad7f](https://github.com/bitnami/charts/commit/b46ad7f27b2a303dd31d1cf2149d792ee50344c9)), closes [#35229](https://github.com/bitnami/charts/issues/35229)

## <small>4.0.54 (2025-07-18)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35199) ([5dbf23f](https://github.com/bitnami/charts/commit/5dbf23f5749290e18b5aab1cf092d6976ecc8260)), closes [#35199](https://github.com/bitnami/charts/issues/35199)

## <small>4.0.53 (2025-07-16)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35162) ([4a917ca](https://github.com/bitnami/charts/commit/4a917ca180d03d0ceaab9f3594890f5b395965f8)), closes [#35162](https://github.com/bitnami/charts/issues/35162)

## <small>4.0.52 (2025-07-15)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35146) ([9d1bf06](https://github.com/bitnami/charts/commit/9d1bf0618169c028d23b5270dfe2d0b08bfd9e6f)), closes [#35146](https://github.com/bitnami/charts/issues/35146)

## <small>4.0.51 (2025-07-15)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35141) ([aec53c2](https://github.com/bitnami/charts/commit/aec53c20776d192a12915c20c07c7701d2c1d02f)), closes [#35141](https://github.com/bitnami/charts/issues/35141)

## <small>4.0.50 (2025-07-15)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35075) ([2b9942b](https://github.com/bitnami/charts/commit/2b9942b7625372f3bb4c8a9b9eaf56ee68497981)), closes [#35075](https://github.com/bitnami/charts/issues/35075)

## <small>4.0.49 (2025-07-11)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35022) ([e72e7a9](https://github.com/bitnami/charts/commit/e72e7a919b3fad043542a0191deec10ab80240c6)), closes [#35022](https://github.com/bitnami/charts/issues/35022)

## <small>4.0.48 (2025-07-11)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35015) ([8482574](https://github.com/bitnami/charts/commit/848257489bb7819bc6b569441de07145a73da7fd)), closes [#35015](https://github.com/bitnami/charts/issues/35015)

## <small>4.0.47 (2025-07-11)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#35013) ([0ad6f9b](https://github.com/bitnami/charts/commit/0ad6f9bcb1d8ec40266bca5fc565abea1a1c9519)), closes [#35013](https://github.com/bitnami/charts/issues/35013)

## <small>4.0.46 (2025-07-10)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34999) ([baa6a1c](https://github.com/bitnami/charts/commit/baa6a1c3e104fe6f0718bbb484d32cef4dfc0c7c)), closes [#34999](https://github.com/bitnami/charts/issues/34999)

## <small>4.0.45 (2025-07-10)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34990) ([8903add](https://github.com/bitnami/charts/commit/8903add12e1bed65c94b14f120762678bb09989d)), closes [#34990](https://github.com/bitnami/charts/issues/34990)

## <small>4.0.44 (2025-07-09)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34975) ([8c5998c](https://github.com/bitnami/charts/commit/8c5998c8b262a4656bf003d6cc881db5da35e733)), closes [#34975](https://github.com/bitnami/charts/issues/34975)

## <small>4.0.43 (2025-07-09)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34970) ([52c213c](https://github.com/bitnami/charts/commit/52c213c75effb905854e87fbaf5be33c9b380a6b)), closes [#34970](https://github.com/bitnami/charts/issues/34970)

## <small>4.0.42 (2025-07-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34886) ([08e5f70](https://github.com/bitnami/charts/commit/08e5f709c711a72616bf960ec859946c7603e889)), closes [#34886](https://github.com/bitnami/charts/issues/34886)

## <small>4.0.41 (2025-07-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34860) ([756b985](https://github.com/bitnami/charts/commit/756b985e39208928ec0a11952d6b55d400f9b824)), closes [#34860](https://github.com/bitnami/charts/issues/34860)

## <small>4.0.40 (2025-07-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34852) ([b7eeced](https://github.com/bitnami/charts/commit/b7eeced384731a9f23f6db2c494e39ed9d7f49bf)), closes [#34852](https://github.com/bitnami/charts/issues/34852)

## <small>4.0.39 (2025-07-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34844) ([c5866fc](https://github.com/bitnami/charts/commit/c5866fcd4410dcb4a539a800e6376d9b8a9b0223)), closes [#34844](https://github.com/bitnami/charts/issues/34844)

## <small>4.0.38 (2025-07-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34840) ([f612b07](https://github.com/bitnami/charts/commit/f612b079c3ee238844d5e10a9e28753fc6d63674)), closes [#34840](https://github.com/bitnami/charts/issues/34840)

## <small>4.0.37 (2025-07-07)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34828) ([5780b6e](https://github.com/bitnami/charts/commit/5780b6e21f3ae8d8274d4ba52f00769272e53d62)), closes [#34828](https://github.com/bitnami/charts/issues/34828)

## <small>4.0.36 (2025-07-07)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34820) ([7cd2a48](https://github.com/bitnami/charts/commit/7cd2a48ab77f158ce6f2aad1439835199308f9ba)), closes [#34820](https://github.com/bitnami/charts/issues/34820)

## <small>4.0.35 (2025-07-04)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34802) ([49d9563](https://github.com/bitnami/charts/commit/49d95635464b3757a0a4a6792eaf2199eec27cac)), closes [#34802](https://github.com/bitnami/charts/issues/34802)

## <small>4.0.34 (2025-07-04)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34800) ([676cd87](https://github.com/bitnami/charts/commit/676cd87c4fe2626c68323e2c3aea24d395fcd64e)), closes [#34800](https://github.com/bitnami/charts/issues/34800)

## <small>4.0.33 (2025-07-03)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34779) ([02ae6b5](https://github.com/bitnami/charts/commit/02ae6b52712b5c811f8f3d24e5f9c8272c604471)), closes [#34779](https://github.com/bitnami/charts/issues/34779)

## <small>4.0.32 (2025-07-02)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34776) ([97f9010](https://github.com/bitnami/charts/commit/97f90107b08dc7f427b1da409bccd2226803d793)), closes [#34776](https://github.com/bitnami/charts/issues/34776)

## <small>4.0.31 (2025-07-02)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34769) ([b90db85](https://github.com/bitnami/charts/commit/b90db85b02d6749a7074571eead0b35a2bbb5d72)), closes [#34769](https://github.com/bitnami/charts/issues/34769)

## <small>4.0.30 (2025-07-01)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34761) ([303011d](https://github.com/bitnami/charts/commit/303011d1eeccff7732f8f7aa68f99ae3db616892)), closes [#34761](https://github.com/bitnami/charts/issues/34761)

## <small>4.0.29 (2025-07-01)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34752) ([5e8bfba](https://github.com/bitnami/charts/commit/5e8bfbaf5f5674e80c5a562928347dc2cce3ae93)), closes [#34752](https://github.com/bitnami/charts/issues/34752)

## <small>4.0.28 (2025-07-01)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34744) ([b783814](https://github.com/bitnami/charts/commit/b78381489f6a35a58b9379b9f4aee6bb1b1e3b64)), closes [#34744](https://github.com/bitnami/charts/issues/34744)

## <small>4.0.27 (2025-07-01)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34732) ([cc1529a](https://github.com/bitnami/charts/commit/cc1529abd578de3010754fea72a86515c24fa246)), closes [#34732](https://github.com/bitnami/charts/issues/34732)

## <small>4.0.26 (2025-06-30)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34728) ([a29d746](https://github.com/bitnami/charts/commit/a29d7466f5128d848f5d6c8b2c80e078b858f635)), closes [#34728](https://github.com/bitnami/charts/issues/34728)

## <small>4.0.25 (2025-06-26)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34662) ([0277b32](https://github.com/bitnami/charts/commit/0277b32c53b3c64e18f2e455da43b687c0531f35)), closes [#34662](https://github.com/bitnami/charts/issues/34662)

## <small>4.0.24 (2025-06-24)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34606) ([b20b2e2](https://github.com/bitnami/charts/commit/b20b2e24f95ebb43fc220b20e1542af3d3391a0b)), closes [#34606](https://github.com/bitnami/charts/issues/34606)

## <small>4.0.23 (2025-06-23)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34582) ([c1ec97e](https://github.com/bitnami/charts/commit/c1ec97e7c3d91543848486fb948e2d7bb9dc559c)), closes [#34582](https://github.com/bitnami/charts/issues/34582)

## <small>4.0.22 (2025-06-18)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34539) ([507050b](https://github.com/bitnami/charts/commit/507050bf20cae91b8461e4e08c86b97edfd7f48c)), closes [#34539](https://github.com/bitnami/charts/issues/34539)

## <small>4.0.21 (2025-06-16)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34510) ([8feda18](https://github.com/bitnami/charts/commit/8feda185f76a0159ef74b14b68096ebb83b39c2d)), closes [#34510](https://github.com/bitnami/charts/issues/34510)

## <small>4.0.20 (2025-06-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34419) ([efa1ea5](https://github.com/bitnami/charts/commit/efa1ea55f7c90ccdadcc78cae6cdb56e216a44a8)), closes [#34419](https://github.com/bitnami/charts/issues/34419)

## <small>4.0.19 (2025-06-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34410) ([308563d](https://github.com/bitnami/charts/commit/308563df29b332a4350e1de9a4664889f819132c)), closes [#34410](https://github.com/bitnami/charts/issues/34410)

## <small>4.0.18 (2025-06-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34397) ([477883a](https://github.com/bitnami/charts/commit/477883a8da2aad9bb7fdda2ca5bad58e2b262dcf)), closes [#34397](https://github.com/bitnami/charts/issues/34397)

## <small>4.0.17 (2025-06-11)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34335) ([a77dbeb](https://github.com/bitnami/charts/commit/a77dbeb97385a7f5f52a93eaf894dbbb518748af)), closes [#34335](https://github.com/bitnami/charts/issues/34335)

## <small>4.0.16 (2025-06-06)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34237) ([8ea7856](https://github.com/bitnami/charts/commit/8ea785666fbd5d60d21dde75265c2ac7fe7c7665)), closes [#34237](https://github.com/bitnami/charts/issues/34237)

## <small>4.0.15 (2025-06-05)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34148) ([594bd99](https://github.com/bitnami/charts/commit/594bd99227a95464cf3d13285aa09cb86ca07bd7)), closes [#34148](https://github.com/bitnami/charts/issues/34148)

## <small>4.0.14 (2025-06-05)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34142) ([a38d48b](https://github.com/bitnami/charts/commit/a38d48be3fadf3bf9942f29047491b061b3316d6)), closes [#34142](https://github.com/bitnami/charts/issues/34142)

## <small>4.0.13 (2025-06-03)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34065) ([e66efd1](https://github.com/bitnami/charts/commit/e66efd111f0345c5fafda16b3c604af8d28da7a2)), closes [#34065](https://github.com/bitnami/charts/issues/34065)

## <small>4.0.12 (2025-06-03)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#34059) ([0f59d49](https://github.com/bitnami/charts/commit/0f59d491f4f353f802185825fac41786597c4dad)), closes [#34059](https://github.com/bitnami/charts/issues/34059)

## <small>4.0.11 (2025-05-27)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33899) ([15fab30](https://github.com/bitnami/charts/commit/15fab301c72e589e6a35c8dd1f46ed421b44abbe)), closes [#33899](https://github.com/bitnami/charts/issues/33899)

## <small>4.0.10 (2025-05-27)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33896) ([ecde3a4](https://github.com/bitnami/charts/commit/ecde3a47bb25d47361b5a9a383e214d694f67e5d)), closes [#33896](https://github.com/bitnami/charts/issues/33896)

## <small>4.0.9 (2025-05-23)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33865) ([719f7d1](https://github.com/bitnami/charts/commit/719f7d130c8158889197b5c967b326c6ab4fa92e)), closes [#33865](https://github.com/bitnami/charts/issues/33865)

## <small>4.0.8 (2025-05-22)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33836) ([337a180](https://github.com/bitnami/charts/commit/337a1807f2f036f959e0641b87378067afe053b4)), closes [#33836](https://github.com/bitnami/charts/issues/33836)

## <small>4.0.7 (2025-05-21)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33813) ([fa851a9](https://github.com/bitnami/charts/commit/fa851a96decc3931efff666ee18d1ad5d342f381)), closes [#33813](https://github.com/bitnami/charts/issues/33813)

## <small>4.0.6 (2025-05-20)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33796) ([e80e7a2](https://github.com/bitnami/charts/commit/e80e7a2ac1b2332eabf0171d6c709c5f1fc41f43)), closes [#33796](https://github.com/bitnami/charts/issues/33796)

## <small>4.0.5 (2025-05-19)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33782) ([50d9ac8](https://github.com/bitnami/charts/commit/50d9ac81098246e76389eebb60b6c54d50b1f964)), closes [#33782](https://github.com/bitnami/charts/issues/33782)

## <small>4.0.4 (2025-05-19)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33778) ([e92c7cf](https://github.com/bitnami/charts/commit/e92c7cf8c0f9aece9f48c0f7faf6407b863a4f07)), closes [#33778](https://github.com/bitnami/charts/issues/33778)

## <small>4.0.3 (2025-05-15)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33726) ([730a4aa](https://github.com/bitnami/charts/commit/730a4aa5dde4f7a3e6df121406e646f40f4959f9)), closes [#33726](https://github.com/bitnami/charts/issues/33726)

## <small>4.0.2 (2025-05-13)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33676) ([66916d9](https://github.com/bitnami/charts/commit/66916d9302c201b78a46bad2ed8beb959b07529a)), closes [#33676](https://github.com/bitnami/charts/issues/33676)

## <small>4.0.1 (2025-05-08)</small>

* [bitnami/chainloop] :zap: :arrow_up: Update dependency references (#33580) ([96bd035](https://github.com/bitnami/charts/commit/96bd0359f33e40510525041094eca73a55bc3378)), closes [#33580](https://github.com/bitnami/charts/issues/33580)

## 4.0.0 (2025-05-07)

* [bitnami/chainloop] Release 4.0.0 (#33548) ([c78166d](https://github.com/bitnami/charts/commit/c78166deba01659cecea6eb2c0bf19783ea15fe1)), closes [#33548](https://github.com/bitnami/charts/issues/33548)

## <small>3.0.2 (2025-05-07)</small>

* [bitnami/chainloop] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#333 ([ad1a8c7](https://github.com/bitnami/charts/commit/ad1a8c784c38bdbf23a2c4726ab388667f961c12)), closes [#33343](https://github.com/bitnami/charts/issues/33343)

## <small>3.0.1 (2025-05-07)</small>

* [bitnami/chainloop] Release 3.0.1 (#33472) ([f25f59e](https://github.com/bitnami/charts/commit/f25f59e33c8f5527df67e52b46b9396337a21828)), closes [#33472](https://github.com/bitnami/charts/issues/33472)

## 3.0.0 (2025-05-05)

* [bitnami/chainloop] chore!: :recycle: :boom: :arrow_up: Bump k8s requirements to 1.23 (#33322) ([0d4828e](https://github.com/bitnami/charts/commit/0d4828ee1afc36208f34fc34166a73a77196defe)), closes [#33322](https://github.com/bitnami/charts/issues/33322)

## <small>2.2.24 (2025-04-24)</small>

* [bitnami/chainloop] Release 2.2.24 (#33154) ([b0dcaf6](https://github.com/bitnami/charts/commit/b0dcaf6f4452fd21550adfe50805e6748e3fa07d)), closes [#33154](https://github.com/bitnami/charts/issues/33154)

## <small>2.2.23 (2025-04-01)</small>

* [bitnami/chainloop] Release 2.2.23 (#32720) ([a2cfa00](https://github.com/bitnami/charts/commit/a2cfa00158043e20f1e6d92dd9b2182d1652311f)), closes [#32720](https://github.com/bitnami/charts/issues/32720)

## <small>2.2.22 (2025-04-01)</small>

* [bitnami/chainloop] Release 2.2.22 (#32696) ([683de85](https://github.com/bitnami/charts/commit/683de85302c533fb31e6b2244316c798cc288b94)), closes [#32696](https://github.com/bitnami/charts/issues/32696)

## <small>2.2.21 (2025-03-31)</small>

* [bitnami/chainloop] Release 2.2.21 (#32691) ([5b1d179](https://github.com/bitnami/charts/commit/5b1d179a321119b621e64d829c6d4e8205b33456)), closes [#32691](https://github.com/bitnami/charts/issues/32691)

## <small>2.2.20 (2025-03-28)</small>

* [bitnami/chainloop] Release 2.2.20 (#32659) ([0656c2a](https://github.com/bitnami/charts/commit/0656c2a976a9c803a919dda912f2cb9eb771792e)), closes [#32659](https://github.com/bitnami/charts/issues/32659)

## <small>2.2.19 (2025-03-25)</small>

* [bitnami/chainloop] Release 2.2.19 (#32598) ([ec46980](https://github.com/bitnami/charts/commit/ec46980d2ee0434230278c793d6a200a6e604e1d)), closes [#32598](https://github.com/bitnami/charts/issues/32598)

## <small>2.2.18 (2025-03-24)</small>

* [bitnami/chainloop] Release 2.2.18 (#32583) ([1225654](https://github.com/bitnami/charts/commit/12256546a656d9aedc00c2fc4687249f75d0fc2a)), closes [#32583](https://github.com/bitnami/charts/issues/32583)

## <small>2.2.17 (2025-03-18)</small>

* [bitnami/chainloop] Release 2.2.17 (#32504) ([47e5d4c](https://github.com/bitnami/charts/commit/47e5d4cec8978c72107c7bd5b59e3ed0b8286743)), closes [#32504](https://github.com/bitnami/charts/issues/32504)

## <small>2.2.16 (2025-03-17)</small>

* [bitnami/chainloop] Release 2.2.16 (#32488) ([c584047](https://github.com/bitnami/charts/commit/c584047d5e4e70c813d11db88d37b68badf253aa)), closes [#32488](https://github.com/bitnami/charts/issues/32488)

## <small>2.2.15 (2025-03-14)</small>

* [bitnami/chainloop] Release 2.2.15 (#32458) ([9c1dabd](https://github.com/bitnami/charts/commit/9c1dabd5b730dcff1e68fa0d690ede75f042fb0c)), closes [#32458](https://github.com/bitnami/charts/issues/32458)

## <small>2.2.14 (2025-03-13)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/chainloop] Release 2.2.14 (#32440) ([ae90b4a](https://github.com/bitnami/charts/commit/ae90b4aa0ceab3397658f30e36790abbb59a5561)), closes [#32440](https://github.com/bitnami/charts/issues/32440)

## <small>2.2.13 (2025-03-11)</small>

* [bitnami/chainloop] Release 2.2.13 (#32405) ([2f5fc14](https://github.com/bitnami/charts/commit/2f5fc1470b01632bfa8dd70fdd0618ec5916cde2)), closes [#32405](https://github.com/bitnami/charts/issues/32405)

## <small>2.2.12 (2025-03-05)</small>

* [bitnami/chainloop] Release 2.2.12 (#32325) ([debdca4](https://github.com/bitnami/charts/commit/debdca4ca1815b9bfd1eaea26d929200f2259ac1)), closes [#32325](https://github.com/bitnami/charts/issues/32325)

## <small>2.2.11 (2025-03-04)</small>

* [bitnami/chainloop] Release 2.2.11 (#32280) ([3649ab7](https://github.com/bitnami/charts/commit/3649ab7fdcf8a693c44521ce17083cc4a9c53c34)), closes [#32280](https://github.com/bitnami/charts/issues/32280)

## <small>2.2.10 (2025-03-04)</small>

* [bitnami/chainloop] Release 2.2.10 (#32274) ([f0356b1](https://github.com/bitnami/charts/commit/f0356b16e7cea21adcd6314a7886c7e2c40738e0)), closes [#32274](https://github.com/bitnami/charts/issues/32274)

## <small>2.2.9 (2025-03-03)</small>

* [bitnami/chainloop] Release 2.2.9 (#32237) ([586138d](https://github.com/bitnami/charts/commit/586138d4d4c9fcaaa6ef1f8578d772f27a7b2f4c)), closes [#32237](https://github.com/bitnami/charts/issues/32237)

## <small>2.2.8 (2025-03-03)</small>

* [bitnami/chainloop] Release 2.2.8 (#32233) ([8dcc47c](https://github.com/bitnami/charts/commit/8dcc47cdd228c5c18df2589e0c328a91e63dbfc1)), closes [#32233](https://github.com/bitnami/charts/issues/32233)

## <small>2.2.7 (2025-02-27)</small>

* [bitnami/chainloop] Release 2.2.7 (#32196) ([3d4d32a](https://github.com/bitnami/charts/commit/3d4d32a8c1b8fcffd0268229bc0ee5197788fc3a)), closes [#32196](https://github.com/bitnami/charts/issues/32196)

## <small>2.2.6 (2025-02-25)</small>

* [bitnami/chainloop] Release 2.2.6 (#32159) ([226c1c9](https://github.com/bitnami/charts/commit/226c1c9cc992be95573fe3599cfa0110fe14e9b0)), closes [#32159](https://github.com/bitnami/charts/issues/32159)

## <small>2.2.5 (2025-02-24)</small>

* [bitnami/chainloop] Release 2.2.5 (#32151) ([8a41298](https://github.com/bitnami/charts/commit/8a41298370569fb1ed67e3d7fd7137be3cafcf17)), closes [#32151](https://github.com/bitnami/charts/issues/32151)

## <small>2.2.4 (2025-02-24)</small>

* [bitnami/chainloop] Update deps (#32143) ([d4bc8f8](https://github.com/bitnami/charts/commit/d4bc8f853b0f73ac11cdbbced51ab985035a61df)), closes [#32143](https://github.com/bitnami/charts/issues/32143)

## <small>2.2.3 (2025-02-21)</small>

* [bitnami/chainloop] Release 2.2.3 (#32126) ([2ee6e17](https://github.com/bitnami/charts/commit/2ee6e174a9da9e3b769b819e0fb6892d3b6793c0)), closes [#32126](https://github.com/bitnami/charts/issues/32126)

## <small>2.2.2 (2025-02-21)</small>

* [bitnami/chainloop] Release 2.2.2 (#32124) ([da070fd](https://github.com/bitnami/charts/commit/da070fd7debe12b4f7ed72e77fed286d72a8a701)), closes [#32124](https://github.com/bitnami/charts/issues/32124)

## <small>2.2.1 (2025-02-20)</small>

* [bitnami/chainloop] Release 2.2.1 (#32088) ([14bc7b6](https://github.com/bitnami/charts/commit/14bc7b62832010014b9d1f2672cc20ccd6013cf8)), closes [#32088](https://github.com/bitnami/charts/issues/32088)

## 2.2.0 (2025-02-20)

* [bitnami/chainloop] feat: use new helper for checking API versions (#32046) ([6c2f944](https://github.com/bitnami/charts/commit/6c2f944a521470d4ddb0e0db6ec4bf184a83c1d0)), closes [#32046](https://github.com/bitnami/charts/issues/32046)

## <small>2.1.30 (2025-02-18)</small>

* [bitnami/chainloop] Release 2.1.30 (#31968) ([fb759e9](https://github.com/bitnami/charts/commit/fb759e97967b7e7dd860687a02444d6c08da40d2)), closes [#31968](https://github.com/bitnami/charts/issues/31968)

## <small>2.1.29 (2025-02-18)</small>

* [bitnami/chainloop] Release 2.1.29 (#31967) ([07345d0](https://github.com/bitnami/charts/commit/07345d0dd96ea836d3f32b4b50ea15867367c92e)), closes [#31967](https://github.com/bitnami/charts/issues/31967)

## <small>2.1.28 (2025-02-13)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/chainloop] Release 2.1.28 (#31909) ([9b505d5](https://github.com/bitnami/charts/commit/9b505d5402b8ff7d99efb2ab2472a5f27f6cf94b)), closes [#31909](https://github.com/bitnami/charts/issues/31909)

## <small>2.1.27 (2025-02-12)</small>

* [bitnami/chainloop] Release 2.1.27 (#31880) ([5207914](https://github.com/bitnami/charts/commit/5207914ce2e2bf1c109bfdc104b738f327e6f9ef)), closes [#31880](https://github.com/bitnami/charts/issues/31880)

## <small>2.1.26 (2025-02-11)</small>

* [bitnami/chainloop] Release 2.1.26 (#31865) ([231e1dd](https://github.com/bitnami/charts/commit/231e1dddf6c16efb3a520cdafadce76d3909e1bb)), closes [#31865](https://github.com/bitnami/charts/issues/31865)

## <small>2.1.25 (2025-02-07)</small>

* [bitnami/chainloop] Release 2.1.25 (#31829) ([580b7e1](https://github.com/bitnami/charts/commit/580b7e19358e0b76fec24f7e98ede7104b95bac1)), closes [#31829](https://github.com/bitnami/charts/issues/31829)

## <small>2.1.24 (2025-02-07)</small>

* [bitnami/chainloop] Release 2.1.24 (#31825) ([fd0bde0](https://github.com/bitnami/charts/commit/fd0bde0e902c0df6abc4b83aeffc27f22416558b)), closes [#31825](https://github.com/bitnami/charts/issues/31825)

## <small>2.1.23 (2025-02-04)</small>

* [bitnami/chainloop] Release 2.1.23 (#31745) ([6924e15](https://github.com/bitnami/charts/commit/6924e15bcec2856694a955d5318c63854496c747)), closes [#31745](https://github.com/bitnami/charts/issues/31745)

## <small>2.1.22 (2025-02-03)</small>

* [bitnami/chainloop] Release 2.1.22 (#31719) ([d6ad490](https://github.com/bitnami/charts/commit/d6ad4901581695e688c35537c8fd4e36e4708a5f)), closes [#31719](https://github.com/bitnami/charts/issues/31719)

## <small>2.1.21 (2025-02-03)</small>

* [bitnami/chainloop] Release 2.1.21 (#31708) ([cbb23f2](https://github.com/bitnami/charts/commit/cbb23f2eb4a61ec9e9bc0ea3ef3668626a5c2747)), closes [#31708](https://github.com/bitnami/charts/issues/31708)

## <small>2.1.20 (2025-01-30)</small>

* [bitnami/chainloop] Release 2.1.20 (#31677) ([e62715c](https://github.com/bitnami/charts/commit/e62715ca2dca84b4bc803c0d2a3eed189e8442e8)), closes [#31677](https://github.com/bitnami/charts/issues/31677)

## <small>2.1.19 (2025-01-28)</small>

* [bitnami/chainloop] Release 2.1.19 (#31633) ([980906c](https://github.com/bitnami/charts/commit/980906c314d3e3fa5566309dc9ff92d09f9c357e)), closes [#31633](https://github.com/bitnami/charts/issues/31633)

## <small>2.1.18 (2025-01-24)</small>

* [bitnami/chainloop] Release 2.1.18 (#31559) ([442409f](https://github.com/bitnami/charts/commit/442409f942332f5020cb01efa4019286ec28a222)), closes [#31559](https://github.com/bitnami/charts/issues/31559)

## <small>2.1.17 (2025-01-24)</small>

* [bitnami/chainloop] Release 2.1.17 (#31544) ([e22c5f0](https://github.com/bitnami/charts/commit/e22c5f0f3ad1f8b9ac770a99c9783f6567dd3c40)), closes [#31544](https://github.com/bitnami/charts/issues/31544)

## <small>2.1.16 (2025-01-16)</small>

* [bitnami/chainloop] Release 2.1.16 (#31410) ([71c2a13](https://github.com/bitnami/charts/commit/71c2a13bcbe100cc0fa1897068f70183138fd060)), closes [#31410](https://github.com/bitnami/charts/issues/31410)

## <small>2.1.15 (2025-01-15)</small>

* [bitnami/chainloop] Release 2.1.15 (#31387) ([9eced62](https://github.com/bitnami/charts/commit/9eced62b02e05168a512693d301e9d44e0367ae1)), closes [#31387](https://github.com/bitnami/charts/issues/31387)

## <small>2.1.14 (2025-01-10)</small>

* [bitnami/chainloop] Release 2.1.14 (#31292) ([a7c757b](https://github.com/bitnami/charts/commit/a7c757b5e1b0dc88dcae28d2fd682c02b0fb7e12)), closes [#31292](https://github.com/bitnami/charts/issues/31292)

## <small>2.1.13 (2025-01-10)</small>

* [bitnami/chainloop] Release 2.1.13 (#31286) ([6ddd77f](https://github.com/bitnami/charts/commit/6ddd77f353606f26b7ce2d1f5c7a81b81cb7729c)), closes [#31286](https://github.com/bitnami/charts/issues/31286)

## <small>2.1.12 (2025-01-07)</small>

* [bitnami/chainloop] Release 2.1.12 (#31230) ([2fc4398](https://github.com/bitnami/charts/commit/2fc43986f695551a8d2acef39ffecc123fe136ab)), closes [#31230](https://github.com/bitnami/charts/issues/31230)

## <small>2.1.11 (2025-01-03)</small>

* [bitnami/chainloop] Release 2.1.11 (#31212) ([4f7074b](https://github.com/bitnami/charts/commit/4f7074b0455dffcc934d3859d7a8b9cdfb828240)), closes [#31212](https://github.com/bitnami/charts/issues/31212)

## <small>2.1.10 (2024-12-20)</small>

* [bitnami/chainloop] Release 2.1.10 (#31128) ([707a14c](https://github.com/bitnami/charts/commit/707a14c689d1f9631ea39d92f57f10bea819eee3)), closes [#31128](https://github.com/bitnami/charts/issues/31128)

## <small>2.1.9 (2024-12-19)</small>

* [bitnami/chainloop] Release 2.1.9 (#31114) ([631b365](https://github.com/bitnami/charts/commit/631b365256cd9226a1dfaa922619b6fd6bc8ea83)), closes [#31114](https://github.com/bitnami/charts/issues/31114)

## <small>2.1.8 (2024-12-18)</small>

* [bitnami/chainloop] Release 2.1.8 (#31082) ([43f2e94](https://github.com/bitnami/charts/commit/43f2e9458228d888b0f1f56d84e6cf50e01bdc59)), closes [#31082](https://github.com/bitnami/charts/issues/31082)

## <small>2.1.7 (2024-12-17)</small>

* [bitnami/chainloop] Release 2.1.7 (#31077) ([0d49f76](https://github.com/bitnami/charts/commit/0d49f76b49670a1a4a89b1225d594b9453e73515)), closes [#31077](https://github.com/bitnami/charts/issues/31077)

## <small>2.1.6 (2024-12-16)</small>

* [bitnami/chainloop] Release 2.1.6 (#31063) ([71d47a3](https://github.com/bitnami/charts/commit/71d47a33ded33762148cb959618fbf797e2e814c)), closes [#31063](https://github.com/bitnami/charts/issues/31063)

## <small>2.1.5 (2024-12-16)</small>

* [bitnami/chainloop] Release 2.1.5 (#31056) ([1121b9c](https://github.com/bitnami/charts/commit/1121b9cbad09ac23f928309b0a63120ec7376b16)), closes [#31056](https://github.com/bitnami/charts/issues/31056)

## <small>2.1.4 (2024-12-15)</small>

* [bitnami/chainloop] Release 2.1.4 (#31046) ([27c3ae3](https://github.com/bitnami/charts/commit/27c3ae34ad4f01571422fa5b71ff92c6175e8652)), closes [#31046](https://github.com/bitnami/charts/issues/31046)

## <small>2.1.3 (2024-12-14)</small>

* [bitnami/chainloop] Release 2.1.3 (#31042) ([6a47b92](https://github.com/bitnami/charts/commit/6a47b925d6edb5e8e6ecb3b2a3967341472c256b)), closes [#31042](https://github.com/bitnami/charts/issues/31042)

## <small>2.1.2 (2024-12-13)</small>

* [bitnami/chainloop] Release 2.1.2 (#31030) ([012f6b4](https://github.com/bitnami/charts/commit/012f6b4a29aeb133d369a7a9dc94c7ec47ab994f)), closes [#31030](https://github.com/bitnami/charts/issues/31030)

## <small>2.1.1 (2024-12-11)</small>

* [bitnami/chainloop] Release 2.1.1 (#30991) ([9168f0d](https://github.com/bitnami/charts/commit/9168f0d9fa74fe704695de00ef507755a45252a5)), closes [#30991](https://github.com/bitnami/charts/issues/30991)

## 2.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/chainloop] Detect non-standard images (#30869) ([739c820](https://github.com/bitnami/charts/commit/739c820747264bf5a6c777af547c267191880c07)), closes [#30869](https://github.com/bitnami/charts/issues/30869)

## <small>2.0.51 (2024-12-10)</small>

* [bitnami/chainloop] Release 2.0.51 (#30849) ([e07a5ac](https://github.com/bitnami/charts/commit/e07a5aca0dc34bdbd4e1c074f529b6446563c860)), closes [#30849](https://github.com/bitnami/charts/issues/30849)

## <small>2.0.50 (2024-12-09)</small>

* [bitnami/chainloop] Release 2.0.50 (#30838) ([7540ba4](https://github.com/bitnami/charts/commit/7540ba484d3b120f2f9a00037cc05d85f63e1f83)), closes [#30838](https://github.com/bitnami/charts/issues/30838)

## <small>2.0.49 (2024-12-05)</small>

* [bitnami/chainloop] Release 2.0.49 (#30808) ([13c83d3](https://github.com/bitnami/charts/commit/13c83d3a773da9f89d213f88082dfecdbe5ac80f)), closes [#30808](https://github.com/bitnami/charts/issues/30808)

## <small>2.0.48 (2024-12-03)</small>

* [bitnami/chainloop] Release 2.0.48 (#30741) ([6798264](https://github.com/bitnami/charts/commit/67982640075dededecca85819163000efda1f995)), closes [#30741](https://github.com/bitnami/charts/issues/30741)

## <small>2.0.47 (2024-11-29)</small>

* [bitnami/chainloop] Release 2.0.47 (#30693) ([a9e83fe](https://github.com/bitnami/charts/commit/a9e83feabf7ccf40a7f0260693a099c327fd3073)), closes [#30693](https://github.com/bitnami/charts/issues/30693)

## <small>2.0.46 (2024-11-27)</small>

* [bitnami/chainloop] Release 2.0.46 (#30652) ([83c11ec](https://github.com/bitnami/charts/commit/83c11ecc8c5610548ce5ddd6d0d3fe7ac6f4a9b7)), closes [#30652](https://github.com/bitnami/charts/issues/30652)

## <small>2.0.45 (2024-11-26)</small>

* [bitnami/chainloop] Release 2.0.45 (#30637) ([09f0b9e](https://github.com/bitnami/charts/commit/09f0b9e7c35251170c97525e2bdf591c608cc318)), closes [#30637](https://github.com/bitnami/charts/issues/30637)

## <small>2.0.44 (2024-11-26)</small>

* [bitnami/chainloop] Release 2.0.44 (#30634) ([7780461](https://github.com/bitnami/charts/commit/778046168dc3313d183cd3ced949a0e25c61b5a2)), closes [#30634](https://github.com/bitnami/charts/issues/30634)

## <small>2.0.43 (2024-11-26)</small>

* [bitnami/chainloop] Release 2.0.43 (#30631) ([443a1b1](https://github.com/bitnami/charts/commit/443a1b17974222d5e8ad26c819eababf496fd98f)), closes [#30631](https://github.com/bitnami/charts/issues/30631)

## <small>2.0.42 (2024-11-25)</small>

* [bitnami/chainloop] Release 2.0.42 (#30612) ([597ce3c](https://github.com/bitnami/charts/commit/597ce3cbd41e86e00612e40648ea4d161717f964)), closes [#30612](https://github.com/bitnami/charts/issues/30612)

## <small>2.0.41 (2024-11-24)</small>

* [bitnami/chainloop] Release 2.0.41 (#30611) ([7449373](https://github.com/bitnami/charts/commit/74493731a8cdca2095beb6cd5e68a548d051a3f1)), closes [#30611](https://github.com/bitnami/charts/issues/30611)

## <small>2.0.40 (2024-11-24)</small>

* [bitnami/chainloop] Release 2.0.40 (#30605) ([f29e7aa](https://github.com/bitnami/charts/commit/f29e7aa40d82f5ee914ca9f642743e5b1c4ce128)), closes [#30605](https://github.com/bitnami/charts/issues/30605)

## <small>2.0.39 (2024-11-23)</small>

* [bitnami/chainloop] Release 2.0.39 (#30604) ([8d56c6b](https://github.com/bitnami/charts/commit/8d56c6b725e91614e055650ea42a17cc4d0bb43b)), closes [#30604](https://github.com/bitnami/charts/issues/30604)

## <small>2.0.38 (2024-11-23)</small>

* [bitnami/chainloop] Release 2.0.38 (#30603) ([655c3f6](https://github.com/bitnami/charts/commit/655c3f639f04867b04e24f8583fdb6932b35bea8)), closes [#30603](https://github.com/bitnami/charts/issues/30603)

## <small>2.0.37 (2024-11-23)</small>

* [bitnami/chainloop] Release 2.0.37 (#30601) ([762e13c](https://github.com/bitnami/charts/commit/762e13c8d26d483c2b9c55d05ae35e414e317699)), closes [#30601](https://github.com/bitnami/charts/issues/30601)

## <small>2.0.36 (2024-11-22)</small>

* [bitnami/chainloop] Release 2.0.36 (#30598) ([f456dd9](https://github.com/bitnami/charts/commit/f456dd9a7b4f8ca3c024b3b73b1dfda4a326f762)), closes [#30598](https://github.com/bitnami/charts/issues/30598)

## <small>2.0.35 (2024-11-22)</small>

* [bitnami/chainloop] Release 2.0.35 (#30581) ([c52ccd4](https://github.com/bitnami/charts/commit/c52ccd47ba9334bd99eeb438d2dc188497e50703)), closes [#30581](https://github.com/bitnami/charts/issues/30581)

## <small>2.0.34 (2024-11-21)</small>

* [bitnami/chainloop] Release 2.0.34 (#30564) ([0b466db](https://github.com/bitnami/charts/commit/0b466dbbcae85115aebfb00f69127a3d4c801e79)), closes [#30564](https://github.com/bitnami/charts/issues/30564)

## <small>2.0.33 (2024-11-20)</small>

* [bitnami/chainloop] Release 2.0.33 (#30554) ([0aa971e](https://github.com/bitnami/charts/commit/0aa971edce9b7ae453875fd6ddea102cd8fc4eb9)), closes [#30554](https://github.com/bitnami/charts/issues/30554)

## <small>2.0.32 (2024-11-20)</small>

* [bitnami/chainloop] Release 2.0.32 (#30548) ([37fa14d](https://github.com/bitnami/charts/commit/37fa14d584d99b21678d2688eda56329f6559b86)), closes [#30548](https://github.com/bitnami/charts/issues/30548)

## <small>2.0.31 (2024-11-20)</small>

* [bitnami/chainloop] Release 2.0.31 (#30547) ([e54deff](https://github.com/bitnami/charts/commit/e54deffbf4372ad52d260007d8f70a2fdf926d4d)), closes [#30547](https://github.com/bitnami/charts/issues/30547)

## <small>2.0.30 (2024-11-20)</small>

* [bitnami/chainloop] Release 2.0.30 (#30546) ([3a59c40](https://github.com/bitnami/charts/commit/3a59c40d7226e3afb8518ad65f4dc8f17b846675)), closes [#30546](https://github.com/bitnami/charts/issues/30546)

## <small>2.0.29 (2024-11-20)</small>

* [bitnami/chainloop] Release 2.0.29 (#30542) ([41ace25](https://github.com/bitnami/charts/commit/41ace25a4d6b7e924a9c2a53adda628e6cf97dc1)), closes [#30542](https://github.com/bitnami/charts/issues/30542)

## <small>2.0.28 (2024-11-19)</small>

* [bitnami/chainloop] Release 2.0.28 (#30534) ([7313cc0](https://github.com/bitnami/charts/commit/7313cc031575168ce815336fd5682d80d3f01dcd)), closes [#30534](https://github.com/bitnami/charts/issues/30534)

## <small>2.0.27 (2024-11-19)</small>

* [bitnami/chainloop] Release 2.0.27 (#30532) ([22d854d](https://github.com/bitnami/charts/commit/22d854dff90b38f57bcff3e0c1abc6a3ee004fda)), closes [#30532](https://github.com/bitnami/charts/issues/30532)

## <small>2.0.26 (2024-11-19)</small>

* [bitnami/chainloop] Release 2.0.26 (#30530) ([b850cea](https://github.com/bitnami/charts/commit/b850ceaa528d777b796aa782c7ad59ba814d21c3)), closes [#30530](https://github.com/bitnami/charts/issues/30530)

## <small>2.0.25 (2024-11-19)</small>

* [bitnami/chainloop] Release 2.0.25 (#30521) ([1f47d76](https://github.com/bitnami/charts/commit/1f47d7627b03d37f290ed792891fd554af7246ee)), closes [#30521](https://github.com/bitnami/charts/issues/30521)

## <small>2.0.24 (2024-11-18)</small>

* [bitnami/chainloop] Release 2.0.24 (#30500) ([8bbdddf](https://github.com/bitnami/charts/commit/8bbdddfb52fc6eb70618fe638964caad6091bc26)), closes [#30500](https://github.com/bitnami/charts/issues/30500)

## <small>2.0.23 (2024-11-14)</small>

* [bitnami/chainloop] Release 2.0.23 (#30458) ([1d3c837](https://github.com/bitnami/charts/commit/1d3c837541adc5682cfad6b93f8008f8da26ee15)), closes [#30458](https://github.com/bitnami/charts/issues/30458)

## <small>2.0.22 (2024-11-11)</small>

* [bitnami/chainloop] Release 2.0.22 (#30404) ([7e838d5](https://github.com/bitnami/charts/commit/7e838d58ce589160af84ac0451cd61c272af4097)), closes [#30404](https://github.com/bitnami/charts/issues/30404)

## <small>2.0.21 (2024-11-08)</small>

* [bitnami/chainloop] Release 2.0.21 (#30317) ([f2baa23](https://github.com/bitnami/charts/commit/f2baa23c9c5bbc0f4e4b920bcf70df46df321f29)), closes [#30317](https://github.com/bitnami/charts/issues/30317)

## <small>2.0.20 (2024-11-07)</small>

* [bitnami/chainloop] Release 2.0.20 (#30298) ([162e34d](https://github.com/bitnami/charts/commit/162e34d2b5b3d70233a68d9e0a0f1f0a9c70327d)), closes [#30298](https://github.com/bitnami/charts/issues/30298)

## <small>2.0.19 (2024-11-07)</small>

* [bitnami/chainloop] Release 2.0.19 (#30256) ([84f2357](https://github.com/bitnami/charts/commit/84f2357754cb66ca6377bf493d832cb9d5d17e71)), closes [#30256](https://github.com/bitnami/charts/issues/30256)

## <small>2.0.18 (2024-11-06)</small>

* [bitnami/chainloop] Release 2.0.18 (#30251) ([fd987ea](https://github.com/bitnami/charts/commit/fd987ea05298004f5cd805c6193d7366aabb3ebc)), closes [#30251](https://github.com/bitnami/charts/issues/30251)

## <small>2.0.17 (2024-11-06)</small>

* [bitnami/chainloop] Release 2.0.17 (#30244) ([8a1c430](https://github.com/bitnami/charts/commit/8a1c430c82a2a1542e20ef87e2edc3166628c080)), closes [#30244](https://github.com/bitnami/charts/issues/30244)

## <small>2.0.16 (2024-11-05)</small>

* [bitnami/chainloop] Release 2.0.16 (#30225) ([3d006c9](https://github.com/bitnami/charts/commit/3d006c9c668f2c72f372b34622a7c72ee183e7da)), closes [#30225](https://github.com/bitnami/charts/issues/30225)

## <small>2.0.15 (2024-11-05)</small>

* [bitnami/chainloop] Release 2.0.15 (#30222) ([830bfcc](https://github.com/bitnami/charts/commit/830bfcc15a9df453cd7156dc398e12e3b33c5301)), closes [#30222](https://github.com/bitnami/charts/issues/30222)

## <small>2.0.14 (2024-11-04)</small>

* [bitnami/chainloop] Release 2.0.14 (#30205) ([9883cd3](https://github.com/bitnami/charts/commit/9883cd3b1049803d0f2d54802cdc343c5a53f181)), closes [#30205](https://github.com/bitnami/charts/issues/30205)

## <small>2.0.13 (2024-10-31)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/chainloop] Release 2.0.13 (#30139) ([e54635a](https://github.com/bitnami/charts/commit/e54635ac52cf9397069d66dbe8eb8b6540207d69)), closes [#30139](https://github.com/bitnami/charts/issues/30139)

## <small>2.0.12 (2024-10-25)</small>

* [bitnami/chainloop] Release 2.0.12 (#30083) ([ad4dbb7](https://github.com/bitnami/charts/commit/ad4dbb74036fb82669cfabf66bbdcceb1cd6ff8e)), closes [#30083](https://github.com/bitnami/charts/issues/30083)

## <small>2.0.11 (2024-10-24)</small>

* [bitnami/chainloop] Release 2.0.11 (#30068) ([b1b103f](https://github.com/bitnami/charts/commit/b1b103fd40f5c32acba3dcf492f4f6bd937c204f)), closes [#30068](https://github.com/bitnami/charts/issues/30068)

## <small>2.0.10 (2024-10-23)</small>

* [bitnami/chainloop] Release 2.0.10 (#30054) ([33003d3](https://github.com/bitnami/charts/commit/33003d3dae7efd8bb4af2523227feedc5c1038c7)), closes [#30054](https://github.com/bitnami/charts/issues/30054)

## <small>2.0.9 (2024-10-22)</small>

* [bitnami/chainloop] Release 2.0.9 (#30040) ([5720383](https://github.com/bitnami/charts/commit/57203838c22e88af05c04513456ab980e22fb56c)), closes [#30040](https://github.com/bitnami/charts/issues/30040)

## <small>2.0.8 (2024-10-18)</small>

* [bitnami/chainloop] Remove wrong entries from image verification (#29913) ([080bd03](https://github.com/bitnami/charts/commit/080bd034f0cc91355fc0e83464c9194937e52897)), closes [#29913](https://github.com/bitnami/charts/issues/29913)

## <small>2.0.7 (2024-10-18)</small>

* [bitnami/chainloop] Release 2.0.7 (#29987) ([66dbd97](https://github.com/bitnami/charts/commit/66dbd9756199c4e3d1cf57aa031782abbd6d652b)), closes [#29987](https://github.com/bitnami/charts/issues/29987)

## <small>2.0.6 (2024-10-16)</small>

* [bitnami/chainloop] Release 2.0.6 (#29957) ([ee5f05d](https://github.com/bitnami/charts/commit/ee5f05d0498c5b32127f84d7405de94ffa880f0b)), closes [#29957](https://github.com/bitnami/charts/issues/29957)

## <small>2.0.5 (2024-10-16)</small>

* [bitnami/chainloop] Release 2.0.5 (#29950) ([1ff9e78](https://github.com/bitnami/charts/commit/1ff9e78681aff62d17cf16c7249d79e4191fd878)), closes [#29950](https://github.com/bitnami/charts/issues/29950)

## <small>2.0.4 (2024-10-16)</small>

* [bitnami/chainloop] Release 2.0.4 (#29947) ([3340098](https://github.com/bitnami/charts/commit/334009859c437290d1ae5c2ca3ce6b529f0de0d9)), closes [#29947](https://github.com/bitnami/charts/issues/29947)

## <small>2.0.3 (2024-10-16)</small>

* [bitnami/chainloop] Release 2.0.3 (#29936) ([2719c14](https://github.com/bitnami/charts/commit/2719c1490c5dde079a15f42f63ca74ba9c64e016)), closes [#29936](https://github.com/bitnami/charts/issues/29936)

## <small>2.0.2 (2024-10-16)</small>

* [bitnami/chainloop] Release 2.0.2 (#29917) ([5005343](https://github.com/bitnami/charts/commit/5005343e562061c03f73dfc8b9809c528bbf07a7)), closes [#29917](https://github.com/bitnami/charts/issues/29917)

## <small>2.0.1 (2024-10-08)</small>

* [bitnami/chainloop] Release 2.0.1 (#29823) ([2ca35d5](https://github.com/bitnami/charts/commit/2ca35d58a310f81a9a5e22c7bfc5f51fcac7ba4b)), closes [#29823](https://github.com/bitnami/charts/issues/29823)

## 2.0.0 (2024-10-03)

* [bitnami/chainloop] feat!: :arrow_up: :boom: Bump PostgreSQL to 17.x (#29729) ([3f44baf](https://github.com/bitnami/charts/commit/3f44baf823f78b5b63c4ab3495733e473d070c0c)), closes [#29729](https://github.com/bitnami/charts/issues/29729)

## <small>1.0.14 (2024-10-01)</small>

* [bitnami/chainloop] Release 1.0.14 (#29685) ([ef41798](https://github.com/bitnami/charts/commit/ef417987465fdc0749079b165627174eba90c981)), closes [#29685](https://github.com/bitnami/charts/issues/29685)

## <small>1.0.13 (2024-09-30)</small>

* [bitnami/chainloop] Release 1.0.13 (#29663) ([8aceafc](https://github.com/bitnami/charts/commit/8aceafcd54e0973de53cc77b138f3a8714473be2)), closes [#29663](https://github.com/bitnami/charts/issues/29663)

## <small>1.0.12 (2024-09-23)</small>

* [bitnami/chainloop] Release 1.0.12 (#29575) ([bd2cb3c](https://github.com/bitnami/charts/commit/bd2cb3c6703554b7535e2ca062a7843c2fabb319)), closes [#29575](https://github.com/bitnami/charts/issues/29575)

## <small>1.0.11 (2024-09-19)</small>

* [bitnami/chainloop] Release 1.0.11 (#29540) ([c9af6c6](https://github.com/bitnami/charts/commit/c9af6c64d4f54e2f4bae59a0b4d95203e666cc4e)), closes [#29540](https://github.com/bitnami/charts/issues/29540)

## <small>1.0.10 (2024-09-19)</small>

* [bitnami/chainloop] Release 1.0.10 (#29538) ([fb64b3a](https://github.com/bitnami/charts/commit/fb64b3a038bd6cf15aa6ff53733611d0b46db918)), closes [#29538](https://github.com/bitnami/charts/issues/29538)

## <small>1.0.9 (2024-09-19)</small>

* [bitnami/chainloop] Release 1.0.9 (#29506) ([ea6a6a9](https://github.com/bitnami/charts/commit/ea6a6a963f9c8a01fc9425301263560b69b79c6d)), closes [#29506](https://github.com/bitnami/charts/issues/29506)

## <small>1.0.8 (2024-09-13)</small>

* [bitnami/chainloop] Release 1.0.8 (#29402) ([39ef9f2](https://github.com/bitnami/charts/commit/39ef9f2a38dc67dd9b926bc778292c083814e328)), closes [#29402](https://github.com/bitnami/charts/issues/29402)

## <small>1.0.7 (2024-09-10)</small>

* [bitnami/chainloop] Release 1.0.7 (#29321) ([13d9c8b](https://github.com/bitnami/charts/commit/13d9c8bb9ba3cc3bf5d332ac2eac2e57e0f61f29)), closes [#29321](https://github.com/bitnami/charts/issues/29321)

## <small>1.0.6 (2024-09-05)</small>

* [bitnami/chainloop] Release 1.0.6 (#29227) ([81a3a3a](https://github.com/bitnami/charts/commit/81a3a3a030f695f223d8d81f15838747e9f7a8a8)), closes [#29227](https://github.com/bitnami/charts/issues/29227)

## <small>1.0.5 (2024-09-02)</small>

* [bitnami/chainloop] Release 1.0.5 (#29160) ([f7c95a6](https://github.com/bitnami/charts/commit/f7c95a6917a1891c332dd3f118c36a5be73a262f)), closes [#29160](https://github.com/bitnami/charts/issues/29160)

## <small>1.0.4 (2024-08-28)</small>

* [bitnami/chainloop] Release 1.0.4 (#29093) ([6697fef](https://github.com/bitnami/charts/commit/6697fefe7efe6842ee729f4dfe9aa035f2c4dc4d)), closes [#29093](https://github.com/bitnami/charts/issues/29093)

## <small>1.0.3 (2024-08-23)</small>

* [bitnami/chainloop] Release 1.0.3 (#28996) ([648a0ab](https://github.com/bitnami/charts/commit/648a0ab13c3090b3dff2d816941b33b63a7f1aa9)), closes [#28996](https://github.com/bitnami/charts/issues/28996)

## <small>1.0.2 (2024-08-21)</small>

* [bitnami/chainloop] Release 1.0.2 (#28951) ([4fec93b](https://github.com/bitnami/charts/commit/4fec93be07c368a2e1cefd25f94ed8e06f688e76)), closes [#28951](https://github.com/bitnami/charts/issues/28951)

## <small>1.0.1 (2024-08-20)</small>

* [bitnami/chainloop] Release 1.0.1 (#28940) ([4a2f985](https://github.com/bitnami/charts/commit/4a2f98536264cbca2e971ea65b79683aa95783e2)), closes [#28940](https://github.com/bitnami/charts/issues/28940)

## 1.0.0 (2024-08-19)

* [bitnami/chainloop] Major version 1.0.0: Use development mode by default (#28923) ([9da9f3b](https://github.com/bitnami/charts/commit/9da9f3b33f7abfb1a04f42de47a9802c27166d18)), closes [#28923](https://github.com/bitnami/charts/issues/28923)

## <small>0.1.6 (2024-08-14)</small>

* [bitnami/chainloop] Release 0.1.6 (#28872) ([1f86e8a](https://github.com/bitnami/charts/commit/1f86e8aa22c5571d10ccec60b9260ca002dd815c)), closes [#28872](https://github.com/bitnami/charts/issues/28872)

## <small>0.1.5 (2024-08-13)</small>

* [bitnami/chainloop] Release 0.1.5 (#28862) ([92d3cbf](https://github.com/bitnami/charts/commit/92d3cbf97424186129480cdb9b83aee74643643d)), closes [#28862](https://github.com/bitnami/charts/issues/28862)

## <small>0.1.4 (2024-08-12)</small>

* [bitnami/chainloop] Release 0.1.4 (#28842) ([e80bcfd](https://github.com/bitnami/charts/commit/e80bcfd0766727143d4bc6717c05b47eb994a750)), closes [#28842](https://github.com/bitnami/charts/issues/28842)

## <small>0.1.3 (2024-08-12)</small>

* [bitnami/chainloop] fix: Little issues (#28837) ([1fe5125](https://github.com/bitnami/charts/commit/1fe5125f24ac2adc4be32c0d401184e1d24261fc)), closes [#28837](https://github.com/bitnami/charts/issues/28837)

## <small>0.1.2 (2024-08-09)</small>

* [bitnami/chainloop] Release 0.1.2 (#28809) ([c97158c](https://github.com/bitnami/charts/commit/c97158c9fe2ede0c2d11eb3fc4fe884b3f7aec8c)), closes [#28809](https://github.com/bitnami/charts/issues/28809)

## <small>0.1.1 (2024-08-09)</small>

* [bitnami/chainloop] Add TL;DR (#28805) ([f014571](https://github.com/bitnami/charts/commit/f014571e1e0af9c3d3f6bc8304d3b3765ae18d47)), closes [#28805](https://github.com/bitnami/charts/issues/28805)

## 0.1.0 (2024-08-09)

* New chart: Chainloop (#27100) ([f192ad3](https://github.com/bitnami/charts/commit/f192ad39431ad8117a236d10b89d80da93a32b74)), closes [#27100](https://github.com/bitnami/charts/issues/27100)
